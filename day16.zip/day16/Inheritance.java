package day16;
class Animal{
   void	makeSound(){
		
		System.out.println("This animal makes  sound.");
	}
}
class Dog extends Animal{
	void makeSound() {
		System.out.println("The dog barks.");
	}
}
class Cat extends Animal{
	void makeSound() {
		System.out.println("The cat meows.");
	}
}
public class Inheritance {
	public static void main(String[] args) {
		Animal an = new Animal();
		Cat cc = new Cat();
		Dog dg = new Dog();

cc.makeSound();
dg.makeSound();

	}

}
