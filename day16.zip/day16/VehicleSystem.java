package day16;

class  Vehicle{
	public void startEngine() {
		  System.out.println("Vehicle engine started.....");
	}
}
class Car extends Vehicle{
	public void drive() {
		System.out.println("Car is driving....");
	}
}
class ElectricCar extends Car{
	public void chargeBattery() {
		System.out.println("Electric Car is charging");
	}
}
class Bike extends Vehicle{
	public void kickStart() {
		System.out.println("Bike is kick-started...");
	}
}
public class VehicleSystem {
public static void main(String[] args) {
	Car car = new Car();
	car.startEngine();
	car.drive();
	ElectricCar ec = new ElectricCar();
 ec.chargeBattery();
 car.startEngine();
 Bike bk = new Bike();
 bk.kickStart();
}
}