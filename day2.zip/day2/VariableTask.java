package day2;

public class VariableTask {
 public static void main(String[] args) {
	byte age=20;
	System.out.print("byte is :" +age);
	short Registernumber = 32454;
	System.out.print("short is:" + Registernumber);
	int Aadharnumber = 58736475;
	System.out.println("int is :"+ Aadharnumber);
	long phonenumber = 9656893l;
	System.out.println("long is :" + phonenumber);
	float salary = 40000.88f;
	System.out.println("float is :"+ salary);
	double add = 40000.8877;
	System.out.println("double is :"+add);
	char letter = 'p';
	System.out.println("char is :"+ letter);
	boolean value = true;
	System.out.println("boolean is :"+ value);
	boolean value2 = false;
	System.out.println("bolean is :"+ value2);
	String str = "Am Jaya";
	System.out.println("These are my details");
	
	
}
}
