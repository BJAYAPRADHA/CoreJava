package day2;

public class Task2 {

	public static void main(String[] args) {
		
		 String name1 = "Jaya";
	     String adjective1 = "cheerful";
	     String adjective2 = "productive";
	     String adjective3 = "amused";
	     String noun1 = "kittens";
	     String noun2 = "pancakes";
	     String noun3 = "bongos";
	     String noun4 = "frogs";
	     String noun5 = "yogurt";
	     String noun6 = "unicorn";
	     String verb1 = "march";
	     int number = 2077;
	     String place1 = "moon";
	     String name2 = "gokul";
	     String story = "This morning " +name1 + " woke up feeling " + adjective1+ ".'it is going to be a " + adjective2+" day!'outside,a bunch of "
	     +noun1+ "s were protesting to keep " +noun2 + " in stores.They began to " +verb1+ " to the rhythm of the " +noun3+ ",which made all the " +noun4 +"s very " +adjective3+ " Concerned, "+name1+" texted "+ name2 + ", who flew "+name1+ " to "+ place1+ " and dropped "+name1+ " in a puddle of frozen"+noun5+ "."+ name1+ "woke up in the year" + number+ ", in a world where " + noun6 + "s ruled the world.";
	     System.out.println(story);
	}

}