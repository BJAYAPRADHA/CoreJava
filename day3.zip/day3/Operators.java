package day3;

public class Operators {
	public static void main(String[] args) {
		int num1= 12;
		int num2= 25;
		int num3= 10;
		int num4= 50;
		int num5= 5;
		int num6= 100;
		System.out.println("Enter the first number :" +num1 );
		System.out.println("Enter the second number:" +num2);
		System.out.println("Arithmetic operations :");
		System.out.println("Addition :" + (num1 + num2));
		System.out.println("Subtraction :" + (num1-num2));
		System.out.println("Multiplication :" + (num1 * num2));
		System.out.println("Division :" +(num1 / num2));
		System.out.println("Modolus :" + (num1 % num2));
		
		System.out.println("Relational Operations :");
		System.out.println(num1 + ">" + num2 + ":" + (num1 > num2));
		System.out.println(num1 + "<" + num2 + ":" + (num1 < num2));
	    System.out.println(num1 + ">=" + num2 + ":" + (num1 >= num2));
	    System.out.println(num1 + "<=" + num2 + ":" + (num1 <= num2));
	    System.out.println(num1 + "==" + num2 + ":" + (num1 == num2));
	    System.out.println(num1 + "!=" + num2 + ":" + (num1 != num2));
	    
	    System.out.println("Logical Operations :");
	    System.out.println(num1 + ">" + num3 + "AND" + num2 + "<" + num4 + ":" +(num1 >num3 && num2<num4));
	    System.out.println(num1 + "<" + num5+ "OR" + num2 + ">" + num6 + ":" +(num1 <num3 || num2<num4));
	    
	    System.out.println("Assignment Operations:");
	    System.out.println("Initial value :" + num3);
	    System.out.println("After += :" + (num3 += 12));
	    System.out.println("After -= :" + (num3 -= 12));
	    System.out.println("After *= :" + (num3 *= 12));
	    System.out.println("After /= :" + (num3 /= 10));
	    System.out.println("After %= :" + (num3 %= 12
	    		));
	    
	    
	    System.out.println("Unary Operations:");
	    System.out.println("Initial value :" + num1);
	    System.out.println("After increment :" + (++num1));
	    System.out.println("After decrement :" + (--num1));
	    
	    
	}

}
