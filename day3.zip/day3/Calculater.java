package day3;

import java.util.Scanner;

public class Calculater {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number1 :");
		int num1=sc.nextInt();
		System.out.println("Enter a number2 :");
		int num2=sc.nextInt();
		System.out.println("Addition :"+ (num1 + num2));
		System.out.println("subtraction :"+ (num1 - num2));
		System.out.println("multiplication:"+ (num1 * num2));
		System.out.println("Division:"+ (num1 / num2));
		System.out.println("Modulus :"+ (num1 % num2));
	}

}
