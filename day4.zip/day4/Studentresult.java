package day4;

import java.util.Scanner;

public class Studentresult {
public static void main(String[] args) {
	Scanner studentmark = new Scanner (System.in);
	System.out.println("Enter student mark :");
	int mark = studentmark.nextInt();
	if(mark>=35) {
		System.out.println("passed in your exams");
	}
	else if(mark < 0 && mark >100) {
		System.out.println("Your mark is invalid");
	}
	else {
		System.out.println("failed in your exams");
		
	}
}
}
